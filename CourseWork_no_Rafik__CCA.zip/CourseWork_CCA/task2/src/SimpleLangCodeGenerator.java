/*
* 1- Student: Rafik Deboub
* studentCandNo = 252719
* 2- Sussex University
* 3- Code generator
* Compilers modules 2023
* TASK 2 RISC-V ASSEMBLY LANGUAGE
 */

import org.antlr.v4.runtime.tree.AbstractParseTreeVisitor;
import org.antlr.v4.runtime.tree.TerminalNode;
//import rars.assembler.Macro;

import java.util.HashMap;
import java.util.Map;



// Predefined macros for common operations in RISC-V assembly language
public class SimpleLangCodeGenerator extends AbstractParseTreeVisitor<String> implements SimpleLangVisitor<String>
{


    // Macro definitions for assembly operations...
    // Each macro simplifies common operations in RISC-V assembly language
    private static final String stackMachineMacros = """
    
    
    .macro    PushImm     $number
        li            t1, $number
        sw            t1, (sp)
        addi          sp, sp, -4
    .end_macro
              
                        
    .macro    PushRel     $offset
        lw            t1, $offset(fp)
        sw            t1, (sp)
        addi          sp, sp, -4
    .end_macro
              
              
                        
    .macro    PopRel      $offset
        lw            t1, 4(sp)
        addi          sp, sp, 4
        sw            t1, $offset(fp)
    .end_macro
              
                    
    .macro    Reserve     $bytes
        addi          sp, sp, -$bytes
    .end_macro
              
              
                        
    .macro    Discard     $bytes
        addi          sp, sp, $bytes
    .end_macro
                   
                   
                        
    .macro    SetFP
        mv            fp, sp
    .end_macro
                   
                   
                        
    .macro    SaveFP
        sw            fp, (sp)
        addi          sp, sp, -4
    .end_macro
    
    
                        
    .macro    RestoreFP
        lw            fp, 4(sp)
        addi          sp, sp, 4
    .end_macro
    
    
                        
    .macro    Popt1t2
        lw            t1, 4(sp)
        addi          sp, sp, 4
        lw            t2, 4(sp)
        addi          sp, sp, 4
    .end_macro
    
    
            
    .macro    CompGT
        Popt1t2
        li            t0, 1
        sw            t0, (sp)
        bgt           t1, t2, exit
        sw            zero, (sp)
    exit:
        addi          sp, sp, -4
    .end_macro
    
    
                        
    .macro    CompGE
        Popt1t2
        li            t0, 1
        sw            t0, (sp)
        bge           t1, t2, exit
        sw            zero, (sp)
    exit:
        addi          sp, sp, -4
    .end_macro
    
    
             
    .macro     CompL
        Popt1t2
        li            t0, 1
        sw            t0, (sp)
        blt           t1, t2, exit
        sw            zero, (sp)
    exit
        addi          sp, sp, -4
    .end_macro
    
    
     
    .macro     LessEq
        Popt1t2
        li            t0, 1
        sw            t0, (sp)
        ble           t1, t2, exit
        sw            zero, (sp)
    exit:
        addi          sp, sp, -4
    .end_macro
    
    
                 
    .macro    CompEq
        Popt1t2
        li            t0, 1
        sw            t0, (sp)
        beq           t1, t2, exit
        sw            zero, (sp)
    exit:
        addi          sp, sp, -4
    .end_macro
    
    
                        
    .macro    Invert
        lw            t1, 4(sp)
        li            t0, 1
        sw            t0, 4(sp)
        beqz          t1, exit
        sw            zero, 4(sp)
    exit:
    .end_macro
    
    
                        
    .macro    Plus
        Popt1t2
        add           t1, t1, t2
        sw            t1, (sp)
        addi          sp, sp, -4
    .end_macro
    
    
                        
    .macro    Minus
        Popt1t2
        sub           t1, t1, t2
        sw            t1, (sp)
        addi          sp, sp, -4
    .end_macro
    
    
                        
    .macro    Times
        Popt1t2
        mul           t1, t1, t2
        sw            t1, (sp)
        addi          sp, sp, -4
    .end_macro
    
    
    
    .macro    Divide
        Popt1t2
        div           t1, t1, t2
        sw            t1, (sp)
        addi          sp, sp, -4
    .end_macro
    
    
   
    .macro    LogicalAnd
        Popt1t2
        and           t1, t1, t2
        sw            t1, (sp)
        addi          sp, sp, -4
    .end_macro
    
    
    
    .macro    LogicalOr
        Popt1t2
        or           t1, t1, t2
        sw            t1, (sp)
        addi          sp, sp, -4
    .end_macro
    
    
    
    .macro    LogicalXor
        Popt1t2
        xor           t1, t1, t2
        sw            t1, (sp)
        addi          sp, sp, -4
    .end_macro 
    
    
    
    .macro    Jump        $address
        j            $address
    .end_macro
         
         
                        
    .macro    JumpTrue    $address
        lw            t1, 4(sp)
        addi          sp, sp, 4
        beqz          t1, exit
        j             $address
    exit:
    .end_macro
            
            
                        
    .macro    Invoke      $address
        jal           next
    next:
        mv            t1, ra
        addi          t1, t1, 20
        sw            t1, (sp)
        addi          sp, sp, -4
        j             $address
    .end_macro
        
        
                        
    .macro    Return      $bytes
        lw            t1, 4(sp)
        addi          sp, sp, 4
        addi          sp, sp, $bytes
        jr            t1
    .end_macro
          
          
                        
    .macro    Print
        li            a7, 1
        lw            a0, 4(sp)
        addi          sp, sp, 4
        ecall
    .end_macro
         
         
                        
    .macro    PrintSpace
        li            a7, 11
        li            a0, 32
        ecall
    .end_macro
    
    
    
    .macro    PrintNewLine
        li            a7, 11
        li            a0, 10
        ecall
    .end_macro
                                               
    """;

    // data structure declaration
    // This records the offset of each parameter: fp '+' n
    // Map for recording the offset of each local variable in the stack frame
    private final Map<String, Integer> localVars = new HashMap<>();

    // For simplicity, we will just use labels of the form "label_[some integer]"
    // Counter for generating unique labels (e.g., for loops and conditional statements)
    private int labelCounter = 0;





    // Method to visit the entire program and process each declaration
    public String visitProgram(SimpleLangParser.ProgContext ctx, String[] args)
    {
        StringBuilder sb = new StringBuilder();

        // return value
        sb.append("""
        .text
                        
        # bootstrap loader that runs main()
        
        boot:
        
            PushImm     0       # return value
        
        """);


        for (int i = args.length - 1; i >= 0; --i) {

            if (args[i].equals("true")) {

                sb.append("""
                    PushImm     1
                """);

            } else if (args[i].equals("false")) {

                sb.append("""
                    PushImm     0
                """);

            }

            else {

                try {
                    sb.append(String.format("""
                        PushImm     %d
                    """, Integer.parseInt(args[i]))
                    );

                } catch (NumberFormatException nfe) {
                    throw new RuntimeException(nfe);
                }

            }

        }

        sb.append("""
            Invoke      main
            lw          a0, 4(sp)
            addi        sp, sp, 4
            li          a7, 10
            ecall
        """);

        for (int i = 0; i < ctx.dec().size(); ++i) {
            sb.append(visit(ctx.dec().get(i)));
        }

        return (stackMachineMacros + sb.toString());
    }





    // Method to process function declarations
    @Override public String visitDec(SimpleLangParser.DecContext ctx)
    {

        StringBuilder sb = new StringBuilder();

        sb.append(String.format("""
        %s:
        """, ctx.typed_idfr(0).Idfr().getText())
        );

        sb.append("""
            SaveFP
            SetFP
        """
        );

        /*
          New FP (and SP initially)
                        points to -> [(available)]
                                     [Old FP]
                                     [Return address]
                                     [Param 0]
                                     ...
                                     [Param (params.size() - 1)]
                                     [Return value]
        */


        for (int i = 0; i < ctx.vardec.size(); ++i) {
            SimpleLangParser.Typed_idfrContext typedIdfr = ctx.vardec.get(i);
            localVars.put(typedIdfr.Idfr().getText(), 4 + 8 + i * 4);
        }

        sb.append(visit(ctx.body()));

        sb.append(String.format("""
            PopRel      %d
        """, 4 + 8 + ctx.vardec.size() * 4)
        );

        sb.append(String.format("""
            RestoreFP
            Return      %d
        """, ctx.vardec.size() * 4)
        );

        localVars.clear();

        return sb.toString();
    }





    // Method to process the body of functions or blocks
    @Override public String visitBody(SimpleLangParser.BodyContext ctx)
    {

        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < ctx.ene.size(); ++i) {
            sb.append(visit(ctx.ene.get(i)));
            if (i != ctx.ene.size() - 1) {
                sb.append("""
                    Discard     4
                """
                );
            }
        }

        return sb.toString();

    }

//    @Override
//    public String visitDeclarations(SimpleLangParser.DeclarationsContext ctx)
//    {
//        StringBuilder sb = new StringBuilder();
//
//        String variableName = ctx.typed_idfr().Idfr().getText();
//        String variableValue = visit(ctx.exp());
//
//        // Assuming the variable is an integer for simplicity
//        sb.append(String.format("""
//        # Declaration: %s
//        %s: .word %s
//        """, variableName, variableName, variableValue));
//
//        return sb.toString();
//
//    }



    // Method to process block structures
    @Override public String visitBlock(SimpleLangParser.BlockContext ctx)
    {

        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < ctx.ene.size(); ++i) {
            sb.append(visit(ctx.ene.get(i)));
            if (i != ctx.ene.size() - 1) {
                sb.append("""
                    Discard     4
                """
                );
            }
        }

        return sb.toString();

    }





    @Override
    public String visitDeclarationExpression(SimpleLangParser.DeclarationExpressionContext ctx) {
        StringBuilder sb = new StringBuilder();
        int offset = 4 + 8 * localVars.size() * 4;
        localVars.put(ctx.typed_idfr().Idfr().getText(), offset);

        sb.append(visit(ctx.exp()));

        sb.append(String.format("""
                PopRel      (%d)
                """, offset
        ));

        sb.append("""
                PushImm     0 
                """
        );
        return sb.toString();
    }




    // Method to process assignment expressions
    @Override public String visitAssignExpr(SimpleLangParser.AssignExprContext ctx)
    {

        StringBuilder sb = new StringBuilder();

        sb.append(visit(ctx.exp()));
        sb.append(String.format("""
            PopRel      (%d)
        """, localVars.get(ctx.Idfr().getText()))
        );

        sb.append("""
            PushImm     0       # dummy value
        """);

        return sb.toString();

    }




    // Method to process binary operation expressions
    @Override public String visitBinOpExpr(SimpleLangParser.BinOpExprContext ctx)
    {

        StringBuilder sb = new StringBuilder();

        sb.append(visit(ctx.exp(1)));
        sb.append(visit(ctx.exp(0)));

        switch (((TerminalNode) (ctx.binop().getChild(0))).getSymbol().getType()) {


            case SimpleLangParser.Eq -> sb.append("""
                CompEq
            """
            );

            case SimpleLangParser.Less -> sb.append("""
                CompGE
                Invert                   
            """
            );

            case SimpleLangParser.LessEq -> sb.append("""
                LessEq                   
            """
            );

            case SimpleLangParser.Plus -> sb.append("""
                Plus
            """
            );

            case SimpleLangParser.Minus -> sb.append("""
                Minus
            """
            );

            case SimpleLangParser.Times -> sb.append("""
                Times
            """
            );
            case SimpleLangParser.Greater -> sb.append("""
                CompGT
            """
            );

            case SimpleLangParser.GreaterEq -> sb.append("""
                CompGE
             """
            );

            case SimpleLangParser.Divide -> sb.append("""
                Divide
             """
            );

            case SimpleLangParser.And -> sb.append("""
                LogicalAnd
             """
            );
            case SimpleLangParser.Or -> sb.append("""
                LogicalOr
             """
            );
            case SimpleLangParser.Xor -> sb.append("""
                LogicalXor
             """
            );


            default -> throw new RuntimeException("Shouldn't be here - wrong binary operator.");

        }

        return sb.toString();
    }




    // Method to process function invocation expressions
    @Override public String visitInvokeExpr(SimpleLangParser.InvokeExprContext ctx)
    {

        StringBuilder sb = new StringBuilder();

        // return value
        sb.append("""
            PushImm     0       # return value
        """);

        for (int i = ctx.args.size() - 1; i >= 0; --i) {

            sb.append(visit(ctx.args.get(i)));

        }

        sb.append(String.format("""
            Invoke      %s
        """, ctx.Idfr().getText())
        );

        return sb.toString();

    }





    // Method to process 'block' loop expressions
    @Override public String visitBlockExpr(SimpleLangParser.BlockExprContext ctx)
    {
        return visit(ctx.block());
    }





    // Method to process 'if' conditional expressions
    @Override public String visitIfExpr(SimpleLangParser.IfExprContext ctx)
    {
        StringBuilder sb = new StringBuilder();

        String thenLabel = String.format("label_%d", labelCounter++);
        String exitLabel = String.format("label_%d", labelCounter++);

        sb.append(visit(ctx.exp()));

        sb.append(String.format("""
            Invert
            JumpTrue    %s
        """, thenLabel)
        );

        sb.append(visit(ctx.block(0)));

        sb.append(String.format("""
            Jump        %s
        """, exitLabel)
        );

        sb.append(String.format("""
        %s:
        """, thenLabel)
        );

        sb.append(visit(ctx.block(1)));



        sb.append(String.format("""
        %s:
        """, exitLabel)
        );

        return sb.toString();
    }




    // Method to process 'while' loop expressions
    @Override
    public String visitWhileExpr(SimpleLangParser.WhileExprContext ctx) {
        StringBuilder sb = new StringBuilder();

        String loopStartLabel = String.format("label_%d", labelCounter++);
        String loopEndLabel = String.format("label_%d", labelCounter++);

        sb.append("""
                PushImm     0
         """);

        sb.append(String.format("""
        %s:
    """, loopStartLabel));

        sb.append(visit(ctx.exp()));

        sb.append(String.format("""
        Invert
        JumpTrue    %s
    """, loopEndLabel));

        sb.append(visit(ctx.block()));

        sb.append("""
                Discard     4 
                """);

        sb.append(String.format("""
        Jump        %s
    """, loopStartLabel));



        sb.append(String.format("""
        %s:
    """, loopEndLabel));

        return sb.toString();
    }




    // Method to process 'repeat' loop expressions

    @Override
    public String visitRepeatExpr(SimpleLangParser.RepeatExprContext ctx) {
        StringBuilder sb = new StringBuilder();

        String loopStartLabel = String.format("label_%d", labelCounter++);
        String loopEndLabel = String.format("label_%d", labelCounter++);

        sb.append("""
            PushImm     0
    """);

        sb.append(String.format("""
    %s:
    """, loopStartLabel));

        sb.append(visit(ctx.block())); // Process the body of the repeat loop



        sb.append("""
                Discard     4 
                """);



        sb.append(visit(ctx.exp()));   // Evaluate the until condition



        sb.append(String.format("""
                 
                 JumpTrue    %s
                     """, loopEndLabel));


        sb.append(String.format("""
          Jump        %s
               """,
                loopStartLabel));

        sb.append(String.format("""
        %s:
         """, loopEndLabel));

        return sb.toString();
    }





    // Method to process 'print' expressions
    @Override public String visitPrintExpr(SimpleLangParser.PrintExprContext ctx)
    {

        StringBuilder sb = new StringBuilder();

        if (ctx.exp().getClass() == SimpleLangParser.SpaceExprContext.class) {
            sb.append("""
                PrintSpace
            """
            );

        } else if (ctx.exp().getClass() == SimpleLangParser.NewLineExprContext.class) {
            sb.append("""
                    PrintNewLine
                    """
            );

        } else {
            sb.append(visit(ctx.exp()));
            sb.append("""
                Print
            """
            );
        }

        sb.append("""
            PushImm     0       # dummy value
        """);

        return sb.toString();
    }






    // Method to process 'space' expressions
    @Override public String visitSpaceExpr(SimpleLangParser.SpaceExprContext ctx)
    {

        StringBuilder sb = new StringBuilder();

        sb.append("""
            PushImm     0       # dummy value
        """);

        return sb.toString();
    }




    // Method to process identifier expressions (variable access)
    @Override public String visitIdExpr(SimpleLangParser.IdExprContext ctx)
    {
        StringBuilder sb = new StringBuilder();

        sb.append(String.format("""
            PushRel     (%d)
        """, localVars.get(ctx.Idfr().getText()))
        );

        return sb.toString();
    }




    // Method to process integer literal expressions
    @Override public String visitIntExpr(SimpleLangParser.IntExprContext ctx)
    {
        StringBuilder sb = new StringBuilder();

        sb.append(String.format("""
            PushImm     %d
        """, Integer.parseInt(ctx.IntLit().getText()))
        );

        return sb.toString();
    }



    // Method to process boolean literal expressions
    @Override
    public String visitBoolExpr(SimpleLangParser.BoolExprContext ctx) {
        StringBuilder sb = new StringBuilder();
        String boolValue = ctx.BoolLit().getText().equals("true") ? "1" : "0";


        sb.append(String.format("""
                PushImm     %s  
                """ , boolValue));

        return sb.toString();


    }






    // Method for processing 'new line' expressions
    @Override
    public String visitNewLineExpr(SimpleLangParser.NewLineExprContext ctx) {
        StringBuilder sb = new StringBuilder();
        sb.append("""
            PushImm     0       # dummy value
        """);
        return sb.toString();
    }



    // Method for processing 'skip' expressions
    @Override
    public String visitSkipExpr(SimpleLangParser.SkipExprContext ctx) {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format( """ 
             
                 PushImm     0    # dummy value
                  """));

        return sb.toString();
    }





    // Override methods for various binary operations (e.g., equality, less than)
    // These methods are not intended to be directly called in the current implementation

    @Override public String visitTyped_idfr(SimpleLangParser.Typed_idfrContext ctx)
    {
       return ctx.Idfr().getText();
    }

    @Override public String visitType(SimpleLangParser.TypeContext ctx)
    {
        throw new RuntimeException("Should not be here!");
    }


    @Override public String visitProg(SimpleLangParser.ProgContext ctx)
    {
        throw new RuntimeException("Should not be here!");
    }

    @Override public String visitEqBinop(SimpleLangParser.EqBinopContext ctx)
    {
        throw new RuntimeException("Should not be here!");
    }
    @Override public String visitLessBinop(SimpleLangParser.LessBinopContext ctx)
    {
        throw new RuntimeException("Should not be here!");
    }
    @Override public String visitLessEqBinop(SimpleLangParser.LessEqBinopContext ctx)
    {
        throw new RuntimeException("Should not be here!");
    }

    @Override
    public String visitGreaterBinop(SimpleLangParser.GreaterBinopContext ctx) {
        throw new RuntimeException("Should not be here!");
    }

    @Override
    public String visitGreaterEqBinop(SimpleLangParser.GreaterEqBinopContext ctx) {
        throw new RuntimeException("Should not be here!");
    }

    @Override public String visitPlusBinop(SimpleLangParser.PlusBinopContext ctx)
    {
        throw new RuntimeException("Should not be here!");
    }
    @Override public String visitMinusBinop(SimpleLangParser.MinusBinopContext ctx)
    {
        throw new RuntimeException("Should not be here!");
    }
    @Override public String visitTimesBinop(SimpleLangParser.TimesBinopContext ctx)
    {
        throw new RuntimeException("Should not be here!");
    }

    @Override
    public String visitDivideBinop(SimpleLangParser.DivideBinopContext ctx) {
        throw new RuntimeException("Should not be here!");
    }

    @Override
    public String visitAndBinop(SimpleLangParser.AndBinopContext ctx) {
        throw new RuntimeException("Should not be here!");
    }

    @Override
    public String visitOrBinop(SimpleLangParser.OrBinopContext ctx) {
        throw new RuntimeException("Should not be here!");
    }

    @Override
    public String visitXorBinop(SimpleLangParser.XorBinopContext ctx) {
        throw new RuntimeException("Should not be here!");
    }

}