/*
 * 1- Student: Rafik Deboub
 * studentCandNo = 252719
 * 2- Sussex University
 * 3- Code generator
 * Compilers modules 2023
 * TASK 1, interpretation based on SimpleLang.g4 in java
 */




import org.antlr.v4.runtime.tree.AbstractParseTreeVisitor;
import org.antlr.v4.runtime.tree.TerminalNode;
import java.util.*;


// Interpreter Class for a specific programs
public class SimpleLangInterpreter extends AbstractParseTreeVisitor<Integer> implements SimpleLangVisitor<Integer> {

    // Global function definitions and a stack of frames for variable scopes
    private final Map<String, SimpleLangParser.DecContext> global_funcs = new HashMap<>();
    private final Stack<Map<String, Integer>> frames = new Stack<>();






    // Method to visit the program, initializes global functions and frame for 'main'
    public Integer visitProgram(SimpleLangParser.ProgContext ctx, String[] args) {

        for (int i = 0; i < ctx.dec().size(); ++i) {

            SimpleLangParser.DecContext dec = ctx.dec(i);
            SimpleLangParser.Typed_idfrContext typedIdf = dec.typed_idfr(0);
            global_funcs.put(typedIdf.Idfr().getText(), dec);

        }


        // Store all global function declarations
        Map<String, Integer> newFrame = new HashMap<>();

        SimpleLangParser.DecContext main = global_funcs.get("main");

        // Prepare the frame for the 'main' function
        for (int i = 0; i < args.length; ++i) {

            if (args[i].equals("true")) {
                newFrame.put(main.vardec.get(i).stop.getText(), 1);
            } else if (args[i].equals("false")) {
                newFrame.put(main.vardec.get(i).stop.getText(), 0);
            } else {
                newFrame.put(main.vardec.get(i).stop.getText(), Integer.parseInt(args[i]));
            }
        }

        frames.push(newFrame);
        return visit(main);

    }



    //**********************************************************************
    // Visit a function declaration, execute its body, and pop its frame
    @Override
    public Integer visitDec(SimpleLangParser.DecContext ctx) {

        Integer returnValue = visit(ctx.body());
        frames.pop();
        return returnValue;

    }
    //**********************************************************************



    //**********************************************************************
    // Visit the body of a declaration, including declarations and expressions
    @Override
    public Integer visitBody(SimpleLangParser.BodyContext ctx) {

        Integer return_Value = null;
        for (int i = 0; i < ctx.ene.size(); i++) {
            SimpleLangParser.ExpContext expr = ctx.ene.get(i);
            return_Value = visit(expr);
        }
        return return_Value;
    }
    //*****************************************************************



    //**********************************************************************
    // Visit a block of expressions, return the value of the last expression
    @Override
    public Integer visitBlock(SimpleLangParser.BlockContext ctx) {
        Integer returnValue = null;
        for (int i = 0; i < ctx.ene.size(); ++i) {
            SimpleLangParser.ExpContext exp = ctx.ene.get(i);
            returnValue = visit(exp);
        }
        return returnValue;
    }
   //**********************************************************************

    //**********************************************************************

//    // Handle a declaration within a body
//    @Override
//    public Integer visitDeclaration(SimpleLangParser.DeclarationContext ctx) {
//
//        SimpleLangParser.ExpContext value = ctx.exp();
//        frames.peek().put(ctx.typed_idfr().Idfr().getText(), visit(value));
//        return null;
//    }

    //**********************************************************************



    //**********************************************************************

    // Handle an assignment expression
    @Override
    public Integer visitAssignExpr(SimpleLangParser.AssignExprContext ctx) {

        SimpleLangParser.ExpContext rhs = ctx.exp();
        frames.peek().replace(ctx.Idfr().getText(), visit(rhs));
        return null;
    }
    //**********************************************************************




    //**********************************************************************
    // Handle binary operation expressions
    @Override
    public Integer visitBinOpExpr(SimpleLangParser.BinOpExprContext ctx) {

        SimpleLangParser.ExpContext operand1 = ctx.exp(0);
        Integer oprnd1 = visit(operand1);
        SimpleLangParser.ExpContext operand2 = ctx.exp(1);
        Integer oprnd2 = visit(operand2);

        switch (((TerminalNode) (ctx.binop().getChild(0))).getSymbol().getType()) {

            case SimpleLangParser.Eq -> {

                return ((Objects.equals(oprnd1, oprnd2)) ? 1 : 0);

            }
            case SimpleLangParser.Less -> {

                return ((oprnd1 < oprnd2) ? 1 : 0);

            }
            case SimpleLangParser.LessEq -> {

                return ((oprnd1 <= oprnd2) ? 1 : 0);

            }
            case SimpleLangParser.Plus -> {

                return oprnd1 + oprnd2;

            }
            case SimpleLangParser.Minus -> {

                return oprnd1 - oprnd2;

            }
            case SimpleLangParser.Times -> {

                return oprnd1 * oprnd2;

            }
            case SimpleLangParser.Greater -> {
                return ((oprnd1 > oprnd2) ? 1 : 0);
            }

            case SimpleLangParser.GreaterEq -> {
                return ((oprnd1 >= oprnd2) ? 1 : 0);
            }

            case SimpleLangParser.Divide -> {
                return (int) (double) (oprnd1 / oprnd2);
            }

            case SimpleLangParser.And -> {
                return (oprnd1 & oprnd2);
            }

            case SimpleLangParser.Or -> {
                return (oprnd1 | oprnd2);
            }
            case SimpleLangParser.Xor -> {
                return (oprnd1 ^ oprnd2);
            }

            default -> throw new RuntimeException("Shouldn't be here - wrong binary operator.");

        }

    }
    //**********************************************************************





    //**********************************************************************
    // Handle function invocation expressions
    @Override
    public Integer visitInvokeExpr(SimpleLangParser.InvokeExprContext ctx) {

        SimpleLangParser.DecContext dec = global_funcs.get(ctx.Idfr().getText());
        Map<String, Integer> newFrame = new HashMap<>();

        for (int i = 0; i < ctx.args.size(); i++) {

            SimpleLangParser.Typed_idfrContext param = dec.vardec.get(i);
            SimpleLangParser.ExpContext exp = ctx.args.get(i);
            newFrame.put(param.Idfr().getText(), visit(exp));
        }

        frames.push(newFrame);
        return visit(dec);

    }
    //**********************************************************************



    //**********************************************************************
    // Visit a block expression
    @Override
    public Integer visitBlockExpr(SimpleLangParser.BlockExprContext ctx) {
        return visit(ctx.block());
    }
    //**********************************************************************



    //**********************************************************************
    // Visit an 'if' expression
    @Override
    public Integer visitIfExpr(SimpleLangParser.IfExprContext ctx) {

        SimpleLangParser.ExpContext cond = ctx.exp();
        Integer condValue = visit(cond);
        if (condValue == 1) {

            SimpleLangParser.BlockContext thenBlock = ctx.block(0);
            return visit(thenBlock);

        } else {

            SimpleLangParser.BlockContext elseBlock = ctx.block(1);
            return visit(elseBlock);

        }

    }
    //**********************************************************************



    //**********************************************************************
    // Visit a 'while' loop expression
    @Override
    public Integer visitWhileExpr(SimpleLangParser.WhileExprContext ctx) {

        SimpleLangParser.ExpContext condition = ctx.exp();
        SimpleLangParser.BlockContext blockContext = ctx.block();

        while (visit(condition) != 0) {
            visit(blockContext);

        }

        return null;

    }
    //**********************************************************************



    //**********************************************************************
    // Visit a 'repeat' loop expression
    @Override
    public Integer visitRepeatExpr(SimpleLangParser.RepeatExprContext ctx) {

       // Integer returnValue = null;
        do {
            visit(ctx.block());
        } while (visit(ctx.exp()) <= 0);
        return null;

    }
    //**********************************************************************


    //**********************************************************************
    // Visit a 'print' expression
    @Override
    public Integer visitPrintExpr(SimpleLangParser.PrintExprContext ctx) {

/*

      // this is a different approach, and it functions the same the code below:


      Method: A
        if (ctx.exp().getText().equals("space")) {
            System.out.print(" ");
        } else if (ctx.exp().getText().equals("newline")) {
            System.out.println();
        } else {
            System.out.print(visit(ctx.exp()));
        }
        return null;
*/


       // Method: B
        SimpleLangParser.ExpContext exp = ctx.exp();

        if (((TerminalNode) exp.getChild(0)).

                getSymbol().

                getType() == SimpleLangParser.Space) {

            System.out.print(" ");

        } else if (((TerminalNode) exp.getChild(0)).

                getSymbol().

                getType() == SimpleLangParser.NewLine) {

            System.out.println();

        } else {

            System.out.print(visit(exp));

        }

        return null;

    }
    //**********************************************************************



    //**********************************************************************
    // Visit a 'space' expression
    @Override public Integer visitSpaceExpr(SimpleLangParser.SpaceExprContext ctx) {
        return null;
    }
    //**********************************************************************



    //**********************************************************************
    // Visit a 'newLine' expression
    @Override
    public Integer visitNewLineExpr(SimpleLangParser.NewLineExprContext ctx) {
        System.out.println();
        return null;
    }
    //**********************************************************************



    //**********************************************************************
    // Visit a 'skip' expression
    @Override
    public Integer visitSkipExpr(SimpleLangParser.SkipExprContext ctx) {
        return null;
    }
    //**********************************************************************


    //**********************************************************************
    // Visit a 'Id' expression
    @Override public Integer visitIdExpr(SimpleLangParser.IdExprContext ctx)
    {
        return frames.peek().get(ctx.Idfr().getText());
    }
    //**********************************************************************



    //**********************************************************************
    // Visit a 'Int' expression
    @Override public Integer visitIntExpr(SimpleLangParser.IntExprContext ctx) {

        return Integer.parseInt(ctx.IntLit().getText());

    }
   //**********************************************************************


    //**********************************************************************
    // Visit a 'bool' expression
    @Override
    public Integer visitBoolExpr(SimpleLangParser.BoolExprContext ctx) {

        String boolLiteral = ctx.BoolLit().getText();

        return Boolean.parseBoolean(boolLiteral)? 1:0;
    }
    //**********************************************************************



    //**********************************************************************
    @Override
    public Integer visitDeclarationExpression(SimpleLangParser.DeclarationExpressionContext ctx) {

        SimpleLangParser.ExpContext value = ctx.exp();
        frames.peek().put(ctx.typed_idfr().Idfr().getText(), visit(value));

        return null;
    }
    //**********************************************************************



    //**********************************************************************
    // Visit a 'eqBinop' expression
    @Override public Integer visitEqBinop(SimpleLangParser.EqBinopContext ctx) {
        throw new RuntimeException("Should not be here!");
    }
    //**********************************************************************



    //**********************************************************************
    // Visit a 'lessBinop' expression
    @Override public Integer visitLessBinop(SimpleLangParser.LessBinopContext ctx) {
        throw new RuntimeException("Should not be here!");
    }
    //**********************************************************************



    //**********************************************************************
    // Visit a 'lessEqBinop' expression
    @Override public Integer visitLessEqBinop(SimpleLangParser.LessEqBinopContext ctx) {
        throw new RuntimeException("Should not be here!");
    }

    //**********************************************************************



    //**********************************************************************
    // Visit a 'greaterBinop' expression
    @Override
    public Integer visitGreaterBinop(SimpleLangParser.GreaterBinopContext ctx) {
        return null;
    }
    //**********************************************************************



    //**********************************************************************
    // Visit a 'greaterEqBinop' Expression
    @Override
    public Integer visitGreaterEqBinop(SimpleLangParser.GreaterEqBinopContext ctx) {
        return null;
    }
    //**********************************************************************




    //**********************************************************************
    // Visit a 'plusBinop' expression
    @Override public Integer visitPlusBinop(SimpleLangParser.PlusBinopContext ctx) {
        throw new RuntimeException("Should not be here!");
    }
    //**********************************************************************



    //**********************************************************************
    // Visit a 'minusBinop' expression
    @Override public Integer visitMinusBinop(SimpleLangParser.MinusBinopContext ctx) {
        throw new RuntimeException("Should not be here!");
    }
    //**********************************************************************



    //**********************************************************************
    // Visit a 'timesBinop' expression
    @Override public Integer visitTimesBinop(SimpleLangParser.TimesBinopContext ctx) {
        throw new RuntimeException("Should not be here!");
    }
    //**********************************************************************


    //**********************************************************************
    // Visit a 'divideBinop' expression
    @Override
    public Integer visitDivideBinop(SimpleLangParser.DivideBinopContext ctx) {
        return null;
    }
    //**********************************************************************



    //**********************************************************************
    // Visit a 'andBinop' expression
    @Override
    public Integer visitAndBinop(SimpleLangParser.AndBinopContext ctx) {
        return null;
    }
    //**********************************************************************


    //**********************************************************************
    // Visit a 'orBinop' expression
    @Override
    public Integer visitOrBinop(SimpleLangParser.OrBinopContext ctx) {
        return null;
    }
    //**********************************************************************




    //**********************************************************************
    // Visit a 'xorBinop' expression
    @Override
    public Integer visitXorBinop(SimpleLangParser.XorBinopContext ctx) {
        return null;
    }
    //**********************************************************************


    //**********************************************************************
    // Visit a 'prog' expression
    @Override public Integer visitProg(SimpleLangParser.ProgContext ctx) {

        throw new RuntimeException("Should not be here!");

    }
    //**********************************************************************



    //**********************************************************************
    // Visit a 'typed_idfr' expression
    @Override
    public Integer visitTyped_idfr(SimpleLangParser.Typed_idfrContext ctx) {
        throw new RuntimeException("Should not be here!");
    }
    //**********************************************************************


    //**********************************************************************
    // Visit a 'type' expression
    @Override public Integer visitType(SimpleLangParser.TypeContext ctx) {
        throw new RuntimeException("Should not be here!");
    }
    //**********************************************************************

}
